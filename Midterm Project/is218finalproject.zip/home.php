<html>
    <title>Home</title>
    <link rel="stylesheet" href="style.css">
<body>
    <h1>YOU HAVE BEEN SUCCESSFULLY SIGNED IN</h1>

    <div class="topnav">
        <a class="active" href="home.php">Home</a>
        <a href="indexxx.php">To-do List</a>
        <a href="completed.php">Completed Tasks</a>
        <a href="Login.html">Signout</a>
    </div>

    <h1>Welcome to Your Self Service Center!</h1>
    <h2>Click on the tab above to manage your task schedule</h2>
    
</body> 
<script>
    function logout() {
        alert("You have been logged out!");
    }
</script>
</html>